package com.example.show;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Main_Recommend extends Fragment {
    Fragment main_recommend_fragment_rank;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.main_recommend, container, false);

        main_recommend_fragment_rank = new Main_Recommend_Fragment();

        getChildFragmentManager().beginTransaction().replace(R.id.recommned_contain, main_recommend_fragment_rank).commit();



        return rootView;
    }
}
