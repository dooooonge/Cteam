package com.example.show;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class User_Comfirm_Activity extends AppCompatActivity {

    EditText user_et_confirm_pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_comfirm);


        //확인버튼
        findViewById(R.id.user_btn_confirm_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(User_Comfirm_Activity.this, Certificate_Director_Activity.class);
                startActivity(intent);
            }
        });

        //리셋버튼
        findViewById(R.id.user_btn_confirm_reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                user_et_confirm_pw.setText("");
            }
        });

    }
}