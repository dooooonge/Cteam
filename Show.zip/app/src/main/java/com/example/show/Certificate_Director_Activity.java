package com.example.show;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.InputStream;

public class Certificate_Director_Activity extends AppCompatActivity {

    EditText et_certi_subject;
    ImageView iv_certi1, iv_certi2, iv_certi3;
    private static final int REQUEST_CODE1 = 101;
    private static final int REQUEST_CODE2 = 102;
    private static final int REQUEST_CODE3 = 103;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_certificate_director);

        iv_certi1 = findViewById(R.id.iv_certi1);
        iv_certi2 = findViewById(R.id.iv_certi2);
        iv_certi3 = findViewById(R.id.iv_certi3);

        //갤러리에서 사진 가져오기
        iv_certi1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
                intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_CODE1);
            }
        });

        iv_certi2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
                intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_CODE2);
            }
        });

        iv_certi3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
                intent.setData(MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_CODE3);
            }
        });

        //기획자 인증 리스트 게시판으로 넘어가야함
        //------------------------------------------------------------------------------------------------------------------
        //확인버튼
        findViewById(R.id.btn_certi_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Certificate_Director_Activity.this, "수정 되었습니다.", Toast.LENGTH_SHORT).show();
            }
        });

        //------------------------------------------------------------------------------------------------------------------
        //리셋버튼
        findViewById(R.id.btn_certi_reset).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_certi_subject = findViewById(R.id.et_certi_subject);
                iv_certi1 = findViewById(R.id.iv_certi1);
                iv_certi2 = findViewById(R.id.iv_certi2);
                iv_certi3 = findViewById(R.id.iv_certi3);

                et_certi_subject.setText("");
                iv_certi1.setImageResource(R.drawable.ic_launcher_foreground);
                iv_certi2.setImageResource(R.drawable.ic_launcher_foreground);
                iv_certi3.setImageResource(R.drawable.ic_launcher_foreground);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE1) {
            if (resultCode == RESULT_OK) {
                try {
                    // 선택한 이미지에서 비트맵 생성
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    Bitmap img = BitmapFactory.decodeStream(in);
                    in.close();
                    // 이미지뷰에 세팅
                    iv_certi1.setImageBitmap(img);

                    Uri uri = data.getData();
                    ClipData clipData = data.getClipData();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }  else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "사진 선택 취소", Toast.LENGTH_LONG).show();
            }
        }

        if (requestCode == REQUEST_CODE2) {
            if (resultCode == RESULT_OK) {
                try {
                    // 선택한 이미지에서 비트맵 생성
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    Bitmap img = BitmapFactory.decodeStream(in);
                    in.close();
                    // 이미지뷰에 세팅
                    iv_certi2.setImageBitmap(img);

                    Uri uri = data.getData();
                    ClipData clipData = data.getClipData();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "사진 선택 취소", Toast.LENGTH_LONG).show();
            }
        }

        if (requestCode == REQUEST_CODE3) {
            if (resultCode == RESULT_OK) {
                try {
                    // 선택한 이미지에서 비트맵 생성
                    InputStream in = getContentResolver().openInputStream(data.getData());
                    Bitmap img = BitmapFactory.decodeStream(in);
                    in.close();
                    // 이미지뷰에 세팅
                    iv_certi3.setImageBitmap(img);

                    Uri uri = data.getData();
                    ClipData clipData = data.getClipData();


                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(this, "사진 선택 취소", Toast.LENGTH_LONG).show();
            }
        }

    }
}