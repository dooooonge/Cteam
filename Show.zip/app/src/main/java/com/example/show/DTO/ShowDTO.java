package com.example.show.DTO;

import java.io.Serializable;

public class ShowDTO implements Serializable {
    private String tile;
    private int regId;

    public ShowDTO(String tile, int regId) {
        this.tile = tile;
        this.regId = regId;
    }

    public String getTile() {
        return tile;
    }

    public void setTile(String tile) {
        this.tile = tile;
    }

    public int getRegId() {
        return regId;
    }

    public void setRegId(int regId) {
        this.regId = regId;
    }
}
