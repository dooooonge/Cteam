package com.example.show.DTO;

import java.io.Serializable;

public class Com_ReView_DTO implements Serializable {
    private String userId, title, content, writedate;
    private int review_list_id;

    public Com_ReView_DTO(String userId, String title, String content, String writedate, int review_list_id) {
        this.userId = userId;
        this.title = title;
        this.content = content;
        this.writedate = writedate;
        this.review_list_id = review_list_id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getWritedate() {
        return writedate;
    }

    public void setWritedate(String writedate) {
        this.writedate = writedate;
    }

    public int getReview_list_id() {
        return review_list_id;
    }

    public void setReview_list_id(int review_list_id) {
        this.review_list_id = review_list_id;
    }
}