package com.example.projectc;

public class MyPageActivity {
}
