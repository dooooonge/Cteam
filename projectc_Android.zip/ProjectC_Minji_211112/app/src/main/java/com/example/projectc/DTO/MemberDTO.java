package com.example.projectc.DTO;

public class MemberDTO {
    private String id, nickname, password, address, email, idnumber, filename, name, kind;

    //로그인 할 때 암호 없이 멤버 정보 가져올 때


    public MemberDTO(String id, String nickname, String address, String kind,
                     String email, String idnumber, String filename, String name) {
        this.id = id;
        this.nickname = nickname;
        this.address = address;
        this.email = email;
        this.idnumber = idnumber;
        this.filename = filename;
        this.name = name;
        this.kind = kind;
    }

    //회원가입 할 때 모든 정보 저장

    public MemberDTO(String id, String nickname, String password, String address,
                     String email, String idnumber, String filename, String name, String kind) {
        this.id = id;
        this.nickname = nickname;
        this.password = password;
        this.address = address;
        this.email = email;
        this.idnumber = idnumber;
        this.filename = filename;
        this.name = name;
        this.kind = kind;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdnumber() {
        return idnumber;
    }

    public void setIdnumber(String idnumber) {
        this.idnumber = idnumber;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }
}