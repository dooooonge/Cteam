package com.example.projectc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projectc.R;

public class join_agree_first_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_agree_first);

        findViewById(R.id.join_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(join_agree_first_Activity.this, JoinActivity.class);
                startActivity(intent);
            }
        });


    }//oncreate
}