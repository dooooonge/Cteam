package com.example.projectc;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

import com.example.projectc.R;

public class CheckboxActivity extends AppCompatActivity {
    private static final String TAG = "main:CheckboxActivity";

    CheckBox checkall, checkfirst, checksecond, checkthird;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        checkall = findViewById(R.id.checkall);
        checkfirst = findViewById(R.id.checkfirst);
        checksecond = findViewById(R.id.checksecond);
        checkthird = findViewById(R.id.checkthird);

    }


}
