package com.example.projectc;

import static com.example.projectc.Common.CommonMethod.ipConfig;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.bumptech.glide.Glide;
import com.example.projectc.ATask.IdCheck;
import com.example.projectc.R;
import com.example.projectc.ATask.JoinInsert;
import com.example.projectc.Common.CommonMethod;
import com.google.android.material.textfield.TextInputLayout;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

public class JoinActivity extends AppCompatActivity {
    private static final String TAG = "main:JoinActivity";

    File imgFile = null;
    String imgFilePath = "", state = "";
    // 이미지처리가 정상적으로 되었을때 onActivityResult에서 데이터를 받기 위한 코드
    //public int reqPicCode = 1004;

    EditText etId, etPassword, etName, etNickname, etAddress, etEmail, etIdnumber, etPwChk, editTextNumberPassword;
    Button btnJoin, btnCancel, btnLoad, btnPhoto;
    ImageView imageView;
    CheckBox checkall, checkfirst, checksecond, checkthird;
    TextView etId_error, etPw_error, etPwChk_error, etName_error, etNickname_error, etEmail_error, etAddress_error, etIdnumber_error ;
    LinearLayout pwChk_outLine, pw_outLine;

    Boolean  PhotoChekck, IdCheck, PwCheck, PwchkCheck, NameCheck, NickNameCheck, AddressCheck, EmailCheck;
    public String imageRealPathA, imageDbPathA;

    File file = null;
    long fileSize = 0;

    final int CAMERA_REQUEST = 1000;
    final int LOAD_IMAGE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join);
        //키보드 올렸을때 화면도 위로 올려주는 메소드
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        imageView = findViewById(R.id.imageView);

        etId = findViewById(R.id.etId);
        etPassword = findViewById(R.id.etPassword);
        etPwChk = findViewById(R.id.etPwChk);
        etName = findViewById(R.id.etName);
        etNickname = findViewById(R.id.etNickname);
        etAddress = findViewById(R.id.etAddress);
        etEmail = findViewById(R.id.etEmail);
        etIdnumber = findViewById(R.id.etIdnumber);
        editTextNumberPassword = findViewById(R.id.editTextNumberPassword);
        etIdnumber_error = findViewById(R.id.etIdnumber_error);

        etId_error = findViewById(R.id.etId_error);
        etPw_error = findViewById(R.id.etPw_error);
        etPwChk_error = findViewById(R.id.etPwChk_error);
        etName_error = findViewById(R.id.etName_error);
        etNickname_error = findViewById(R.id.etNickname_error);
        etEmail_error = findViewById(R.id.etEmail_error);
        etAddress_error = findViewById(R.id.etAddress_error);

        pw_outLine = findViewById(R.id.pw_outLine);
        pwChk_outLine = findViewById(R.id.pwChk_outLine);

        btnJoin = findViewById(R.id.btnJoin);
        btnCancel = findViewById(R.id.btnCancel);
        btnLoad = findViewById(R.id.btnLoad);
        btnPhoto = findViewById(R.id.btnPhoto);

        checkall = (CheckBox) findViewById(R.id.checkall);
        checkfirst = (CheckBox)findViewById(R.id.checkfirst);
        checksecond = (CheckBox)findViewById(R.id.checksecond);
        checkthird = (CheckBox)findViewById(R.id.checkthird);
        PhotoChekck = false;
        IdCheck = false;
        PwCheck = false;
        PwchkCheck = false;
        NameCheck = false;
        NickNameCheck = false;
        EmailCheck = false;
        AddressCheck = false;

        Pattern emailPatttern = Patterns.EMAIL_ADDRESS;




        //!android.util.Patterns.EMAIL_ADDRESS.matcher(etEmail.getText().toString()).matches()
        //ID입력시 유효성 검사
        etId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {      }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                }
            @Override
            public void afterTextChanged(Editable s) {
                int check =0;
                Log.d(TAG, "onTextChanged: "+etId.getText().toString());

                if(!Pattern.matches("^[a-zA-z0-9]{4,12}$", etId.getText().toString())){
                    etId.setBackgroundResource(R.drawable.red_edittext);
                    etId_error.setText("아이디는 영어와 숫자로 4~12의 길이로 구성되야 합니다.");
                    IdCheck = false;
                }else{

                    IdCheck idCheck = new IdCheck(etId.getText().toString());
                    try {
                        check = idCheck.execute().get();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    if(check ==1){
                        etId.setBackgroundResource(R.drawable.red_edittext);
                        etId_error.setText("중복된 아이디 입니다");
                        IdCheck = false;

                    }else{
                        etId.setBackgroundResource(R.drawable.green_edittext);
                        etId_error.setText("사용가능한 아이디입니다.");
                        IdCheck=true;
                    }
                }
            }
        });


        etPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                Log.d(TAG, "onTextChanged: password 입력중");
                //숫자, 문자, 특수문자 모두 포함 (8~15자)
                if(Pattern.matches("^[a-zA-Z0-9!@.#$%^&*?_~]{4,16}$", etPassword.getText().toString())){
                    // 초록색 테두리 적용
                    pw_outLine.setBackgroundResource(R.drawable.green_edittext);
                    etPw_error.setText("적합한 비밀번호입니다");
                    PwCheck = true;
                }else{
                    etPw_error.setText("비밀번호는 영어와 숫자의 조합으로 8~20글자 이하여야 합니다.");
                    pw_outLine.setBackgroundResource(R.drawable.red_edittext);//빨간색 테두리 적용
                    PwCheck = false;
                }
                /*if( etPassword.getText().toString().equals(etPwChk.getText().toString())){
                    pwChk_outLine.setBackgroundResource(R.drawable.green_edittext);  // 초록색 테두리 적용
                    pw_outLine.setBackgroundResource(R.drawable.green_edittext);  // 초록색 테두리 적용
                    etPw_error.setText("비밀번호 확인과 일치합니다.");
                }else{
                    pwChk_outLine.setBackgroundResource(R.drawable.red_edittext);  // 적색 테두리 적용
                    pw_outLine.setBackgroundResource(R.drawable.red_edittext);  // 적색 테두리 적용
                    etPw_error.setText("비밀번호 확인과 일치하지 않습니다.");
                }*/

            }
        });
        //비밀번호와 비밀번호체크의 값이 같으면 입력하는 줄의 색깔이 바뀐다.
        etPwChk.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {


            }

            @Override
            public void afterTextChanged(Editable s) {

                if(etPassword.getText().toString().equals(etPwChk.getText().toString())){
                    pwChk_outLine.setBackgroundResource(R.drawable.green_edittext);  // 초록색 테두리 적용
                   pw_outLine.setBackgroundResource(R.drawable.green_edittext);  // 초록색 테두리 적용
                    etPwChk_error.setText("비밀번호와 일치합니다.");
                    PwchkCheck = true;
                }else{
                    pw_outLine.setBackgroundResource(R.drawable.red_edittext);  // 적색 테두리 적용
                    pwChk_outLine.setBackgroundResource(R.drawable.red_edittext);  // 적색 테두리 적용
                    etPwChk_error.setText("비밀번호와 일치하지 않습니다.");
                    PwchkCheck = false;
               }
            }
        });

        //이메일 유효성 검사
        etEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(emailPatttern.matcher(etEmail.getText().toString()).matches()){
                etEmail.setBackgroundResource(R.drawable.green_edittext);
                    etEmail_error.setText("정상적인 이메일입니다.");
                    EmailCheck = true;
                }else{
                    etEmail.setBackgroundResource(R.drawable.red_edittext);
                    etEmail_error.setText("이메일형식에 맞지 않습니다.");
                    EmailCheck = false;
                }
            }
        });
        etAddress.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                etAddress.setBackgroundResource(R.drawable.green_edittext);
                etAddress_error.setText("주소는 시,군,구까지만 입력해주세요");
                AddressCheck = true;
            }
        });

        etNickname.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                etNickname.setBackgroundResource(R.drawable.green_edittext);

            }
        });

        etName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(Pattern.matches("^[가-힣]*$", etName.getText().toString())){
                    etName.setBackgroundResource(R.drawable.green_edittext);
                    etName_error.setText("");
                    NameCheck = true;
                }else{
                    etName.setBackgroundResource(R.drawable.red_edittext);
                    etName_error.setText("이름은 한글만 입력가능합니다.");
                    NameCheck = false;
                }
            }
        });

        // 이미지뷰에 기본 이미지를 입력한다
        imageView.setImageResource(R.drawable.guest);
        // Uri.parse("android.resource://" + R.class.getPackage().getName() + "/" + R.drawable.guest).toString();


        //이용 약관에 동의해야 가입 버튼 활성화되게 만들기
        checkall.setOnClickListener(new CheckBox.OnClickListener(){
            @Override
            public void onClick(View v){
                if(checkall.isChecked()){
                    checkfirst.setChecked(true);
                    checksecond.setChecked(true);
                    checkthird.setChecked(true);

                }else{
                    checkfirst.setChecked(false);
                    checksecond.setChecked(false);
                    checkthird.setChecked(false);
                }


            }
        });
        checkfirst.setOnClickListener(new CheckBox.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(checkfirst.isChecked()){
                checkfirst.setChecked(true);
                }else{
                    checkfirst.setChecked(false);
                }
                if(!checkfirst.isChecked()||!checksecond.isChecked()||!checkthird.isChecked()){
                    checkall.setChecked(false);
                }
                if(checkfirst.isChecked()&&checksecond.isChecked()&&checkthird.isChecked()){
                    checkall.setChecked(true);
                }
            }
        });
        checksecond.setOnClickListener(new CheckBox.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(checksecond.isChecked()){
                    checksecond.setChecked(true);}
                else{
                    checksecond.setChecked(false);
                }
                if(!checkfirst.isChecked()||!checksecond.isChecked()||!checkthird.isChecked()){
                    checkall.setChecked(false);
                }
                if(checkfirst.isChecked()&&checksecond.isChecked()&&checkthird.isChecked()){
                    checkall.setChecked(true);
                }
            }
        });
        checkthird.setOnClickListener(new CheckBox.OnClickListener(){
            @Override
            public void onClick(View v) {
                if(checkthird.isChecked()){
                    checkthird.setChecked(true);}
                else{
                    checkthird.setChecked(false);
                }
                if(!checkfirst.isChecked()||!checksecond.isChecked()||!checkthird.isChecked()){
                    checkall.setChecked(false);
                }
                if(checkfirst.isChecked()&&checksecond.isChecked()&&checkthird.isChecked()){
                    checkall.setChecked(true);
                }
            }
        });


        // 가입
        btnJoin.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                checkall.setChecked(true);
                if (!checkfirst.isChecked() && !checksecond.isChecked()) {
                    Toast.makeText(JoinActivity.this, "이용약관에 동의해주세요", Toast.LENGTH_SHORT).show();
                    checkall.requestFocus();
                    return;
                }else if(!IdCheck){                 //||!PwCheck||!PwchkCheck||!NameCheck||!EmailCheck
                    Toast.makeText(JoinActivity.this, "아이디 값이 잘못되었습니다.", Toast.LENGTH_SHORT).show();
                    etId.requestFocus();
                }else if(!PwCheck){                 //||!PwCheck||!PwchkCheck||!NameCheck||!EmailCheck
                    Toast.makeText(JoinActivity.this, "비밀번호 형식 잘못되었습니다.", Toast.LENGTH_SHORT).show();
                    etPassword.requestFocus();
                }else if(!PwchkCheck){                 //||!PwCheck||!PwchkCheck||!NameCheck||!EmailCheck
                    Toast.makeText(JoinActivity.this, "비밀번호 확인이 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    etPwChk.requestFocus();
                }else if(!NameCheck){                 //||!PwCheck||!PwchkCheck||!NameCheck||!EmailCheck
                    Toast.makeText(JoinActivity.this, "이름이 한글이 아닙니다.", Toast.LENGTH_SHORT).show();
                    etName.requestFocus();
                }else if(!EmailCheck){                 //||!PwCheck||!PwchkCheck||!NameCheck||!EmailCheck
                    Toast.makeText(JoinActivity.this, "이메일 형식이 잘못되었습니다.", Toast.LENGTH_SHORT).show();
                    etName.requestFocus();
                }else if(!PhotoChekck){                 //||!PwCheck||!PwchkCheck||!NameCheck||!EmailCheck
                    Toast.makeText(JoinActivity.this, "프로필 사진이 없습니다.", Toast.LENGTH_SHORT).show();
                    btnPhoto.requestFocus();
                }else if(!AddressCheck){                 //||!PwCheck||!PwchkCheck||!NameCheck||!EmailCheck
                    Toast.makeText(JoinActivity.this, "주소가 잘못되었습니다.", Toast.LENGTH_SHORT).show();
                    etAddress.requestFocus();
                }else {

                    // 회원가입에 필요한 정보를 가져온다
                    String id = etId.getText().toString();
                    String password = etPassword.getText().toString();
                    String name = etName.getText().toString();
                    String nickname = etNickname.getText().toString();
                    String address = etAddress.getText().toString();
                    String email = etEmail.getText().toString();
                    String postIdnumber = etIdnumber.getText().toString();
                    String idNumberPassword = editTextNumberPassword.getText().toString();
                    String filename = imgFilePath;
                    String idnumber = postIdnumber+idNumberPassword;
                    Log.d(TAG, "onClickJoin: "+id+password+name+nickname+address+email+filename+idnumber);
                    if (id.trim().length() == 0) {
                        Toast.makeText(JoinActivity.this, "아이디를 입력하세요", Toast.LENGTH_SHORT).show();
                        etId.requestFocus();
                        return;
                    }
                    if (password.trim().length() == 0) {
                        Toast.makeText(JoinActivity.this, "비밀번호를 입력하세요", Toast.LENGTH_SHORT).show();
                        etPassword.requestFocus();
                        return;
                    }
                    if (name.trim().length() == 0) {
                        Toast.makeText(JoinActivity.this, "이름을 입력하세요", Toast.LENGTH_SHORT).show();
                        etName.requestFocus();
                        return;
                    }
                    if (address.trim().length() == 0) {
                        Toast.makeText(JoinActivity.this, "주소를 입력하세요", Toast.LENGTH_SHORT).show();
                        etAddress.requestFocus();
                        return;
                    }
                    if (email.trim().length() == 0) {
                        Toast.makeText(JoinActivity.this, "이메일을 입력하세요", Toast.LENGTH_SHORT).show();
                        etEmail.requestFocus();
                        return;
                    }
                    if (postIdnumber.trim().length() == 0 || idNumberPassword.trim().length() == 0) {
                        Toast.makeText(JoinActivity.this, "주민번호 7자리를 입력하세요", Toast.LENGTH_SHORT).show();
                        etIdnumber.requestFocus();
                        return;
                    } else {
                        idnumber = postIdnumber + idNumberPassword;
                    }

                    // 이정보를 비동기 Task로 넘겨 서버에게 전달한다
                    JoinInsert joinInsert = new
                            JoinInsert(id, password, nickname, name, address, idnumber, email, filename);
                    try {
                        state = joinInsert.execute().get().trim();
                        Log.d(TAG, "onClick: state => " + state);
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    if (state.equals("1")) {
                        Toast.makeText(JoinActivity.this,
                                "정상적으로 회원가입이 되었습니다", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(JoinActivity.this,
                                "회원가입에 실패 하였습니다 다시 시도해주세요", Toast.LENGTH_SHORT).show();
                    }


                }
            }//이용약관 체크 여부 if절
        });

        // 취소
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(JoinActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        // 이미지뷰를 클릭하면 사진을 찍어서 데이터를 저장한다
        btnPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 암묵적인텐트 : 사진찍기(카메라를 불러옴)
                Intent picIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                // 일단 이 인텐트가 사용가능한지 체크
                if(picIntent.resolveActivity(getPackageManager()) != null){
                    imgFile = null;
                    // creatFile 매소드를 이용하여 임시파일을 만듬
                    imgFile = createFile();

                    if(imgFile != null){
                        // API24 이상부터는 FileProvider를 제공해야함
                        Uri imgUri = FileProvider.getUriForFile(getApplicationContext(),
                                getApplicationContext().getPackageName()+".fileprovider",
                                imgFile);
                        // 만약에 API24 이상이면
                        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){ // API24
                            picIntent.putExtra(MediaStore.EXTRA_OUTPUT, imgUri);
                        }else {
                            picIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(imgFile));
                        }

                        startActivityForResult(picIntent, CAMERA_REQUEST);
                    }

                }
            }
        });

        btnLoad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_PICK);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), LOAD_IMAGE);
            }
        });


        findViewById(R.id.viewfirst).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(JoinActivity.this, join_agree_first_Activity.class);
                startActivity(intent);
            }
        });


        findViewById(R.id.viewsecond).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(JoinActivity.this, join_agree_second_Activity.class);
                startActivity(intent);
            }
        });
        findViewById(R.id.viewthird).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(JoinActivity.this, join_agree_third_Activity.class);
                startActivity(intent);
            }
        });

    }//oncreate


    private File createFile() {
        // 파일 이름을 만들기 위해 시간값을 생성함
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss")
                .format(new Date());
        String imageFileName = "My" + timestamp;
        // 사진파일을 저장하기 위한 경로
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

        File curFile = null;
        try {
            // 임시파일을 생성함(전체경로),  2번째 suffix 확장자:파일확장자(jpg)
            curFile = File.createTempFile(imageFileName, ".jpg"
                    , storageDir);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 스트링타입으로 임시파일이 있는 곳의 절대경로를 저장함
        imgFilePath = curFile.getAbsolutePath();

        return curFile;
    }

    // 사진찍은 후 데이터를 받는곳
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CAMERA_REQUEST && resultCode == RESULT_OK){
            // 저장처리를 함
            Toast.makeText(JoinActivity.this, "사진이 잘 찍힘", Toast.LENGTH_SHORT).show();

            setPic();
            PhotoChekck = true;
        }else if (requestCode == LOAD_IMAGE && resultCode == RESULT_OK) {

            try {
                String path = "";
                // Get the url from data
                Uri selectedImageUri = data.getData();
                if (selectedImageUri != null) {
                    // Get the path from the Uri
                    path = getPathFromURI(selectedImageUri);
                }
                // 이미지 돌리기 및 리사이즈
                Bitmap newBitmap = CommonMethod.imageRotateAndResize(path);
                if(newBitmap != null){
                    imageView.setImageBitmap(newBitmap);
                }else{
                    Toast.makeText(this, "이미지가 null 입니다...", Toast.LENGTH_SHORT).show();
                }

                imageRealPathA = path;
                Log.d("Sub1Add", "imageFilePathA Path : " + imageRealPathA);
                String uploadFileName = imageRealPathA.split("/")[imageRealPathA.split("/").length - 1];
                imageDbPathA = ipConfig + "/app/resources/" + uploadFileName;

            } catch (Exception e){
                e.printStackTrace();
            }
            PhotoChekck = true;
        }

    }

    // Get the real path from the URI
    public String getPathFromURI(Uri contentUri) {
        String res = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }

    // 사진을 저장처리 하는 곳
    private void setPic() {
        // 이미지뷰의 크기 알아오기
        int targetW = imageView.getWidth();
        int targetH = imageView.getHeight();

        // 사진의 크기 가져오기
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        int photoW = options.outWidth;
        int photoH = options.outHeight;

        // 이미지 크기를 맟출비율을 결정
        int scaleFactor = Math.min(photoW/targetW, photoH/targetH);

        // 이미지뷰의 크기에 맞게 이미지크기를 조절
        options.inJustDecodeBounds = false;
        options.inSampleSize = scaleFactor;
        options.inPurgeable = true;

        // 비트맵 이미지를 생성
        Bitmap bitmap = BitmapFactory.decodeFile(imgFilePath);
        // 이미지를 갤러리에 저장하기
        gelleryAddPic(bitmap);
        // Glide.with(this).load("http://www.selphone.co.kr/homepage/img/team/3.jpg").into(imageView);
        Glide.with(this).load(bitmap).circleCrop().into(imageView);

        //imageView.setImageBitmap(bitmap);

        /*BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 8;
        Bitmap bitmap = BitmapFactory.decodeFile(imgFilePath);
        imageView.setImageBitmap(bitmap);*/

    }

    // 이미지를 갤러리에 저장하기
    private void gelleryAddPic(Bitmap bitmap) {
        FileOutputStream fos;

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){ // API29
            ContentResolver resolver = getContentResolver();

            // 맵구조를 가진 ContentValues : 파일정보를 저장함
            ContentValues contentValues = new ContentValues();
            contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME,
                    "Image_" + "jpg");
            contentValues.put(MediaStore.MediaColumns.MIME_TYPE,
                    "image/jpeg");
            contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + File.separator + "TestFolder");

            Uri imageUri = resolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues );
            try {
                fos = (FileOutputStream) resolver
                        .openOutputStream(Objects.requireNonNull(imageUri));
                Toast.makeText(JoinActivity.this,
                        "fos 작업됨", Toast.LENGTH_SHORT).show();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                Objects.requireNonNull(fos);

            }catch (Exception e){

            }

        }else {
            // 이미지 파일을 스캔해서 갤러리에 저장하기 위한 인텐트
            Intent msIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            // 처음에 CreateFile에서 생성해둔 이미지경로(imgFilePath)를 이용하여 파일객체를 만든다
            File f = new File(imgFilePath);
            Uri contentUri = Uri.fromFile(f);
            msIntent.setData(contentUri);
            // sendBroadcast를 이용하여 저장
            this.sendBroadcast(msIntent);
        }
    }




}