package board;

public interface BoardService {
	
	int board_insert(BoardVO dto);
	
	void board_clear();
}
